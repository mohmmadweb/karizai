"use client";

import { createContext, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import type { SmartRouter } from "@/lib/smart-routing";

type RoutersContextValue = {
  routers: SmartRouter[];
  /** Returns the id of the new router. */
  addRouter: (name: string, description: string) => string;
  updateRouter: (id: string, change: Partial<Omit<SmartRouter, "id" | "isDefault">>) => void;
  /** The default router cannot be removed. */
  removeRouter: (id: string) => void;
};

const RoutersContext = createContext<RoutersContextValue | null>(null);

/**
 * Smart routers of the organization. They are loaded from the server store
 * (`/api/routers`) and every change is saved back after a short wait.
 */
export function RoutersProvider({ children }: { children: ReactNode }) {
  const [routers, setRouters] = useState<SmartRouter[]>([]);
  const [loaded, setLoaded] = useState(false);
  const counter = useRef(0);

  useEffect(() => {
    fetch("/api/routers")
      .then((response) => response.json() as Promise<{ routers: SmartRouter[] }>)
      .then((data) => setRouters(data.routers))
      .catch(() => undefined)
      .finally(() => setLoaded(true));
  }, []);

  useEffect(() => {
    if (!loaded) return;
    const timer = setTimeout(() => {
      void fetch("/api/routers", { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ routers }) }).catch(() => undefined);
    }, 300);
    return () => clearTimeout(timer);
  }, [loaded, routers]);

  const value = useMemo<RoutersContextValue>(
    () => ({
      routers,
      addRouter: (name, description) => {
        const id = `router-${Date.now().toString(36)}-${++counter.current}`;
        setRouters((list) => [...list, { id, name: name.trim(), description: description.trim(), isDefault: false, groupIds: [], members: [] }]);
        return id;
      },
      updateRouter: (id, change) => setRouters((list) => list.map((item) => (item.id === id ? { ...item, ...change } : item))),
      removeRouter: (id) => setRouters((list) => list.filter((item) => item.id !== id || item.isDefault)),
    }),
    [routers],
  );

  return <RoutersContext.Provider value={value}>{loaded ? children : null}</RoutersContext.Provider>;
}

export function useRouters(): RoutersContextValue {
  const value = useContext(RoutersContext);
  if (!value) throw new Error("useRouters must be used inside RoutersProvider");
  return value;
}
