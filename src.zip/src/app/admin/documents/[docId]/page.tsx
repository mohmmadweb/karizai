import { Suspense } from "react";
import { ListSkeleton } from "@/components/shared/list-skeleton";
import { DocumentDetail } from "@/features/documents/components/detail/document-detail";

async function DocContent({ params }: { params: Promise<{ docId: string }> }) {
  const { docId } = await params;
  return <DocumentDetail docId={docId} />;
}

export default function DocumentPage({ params }: { params: Promise<{ docId: string }> }) {
  return (
    <Suspense fallback={<ListSkeleton title="اسناد" />}>
      <DocContent params={params} />
    </Suspense>
  );
}
