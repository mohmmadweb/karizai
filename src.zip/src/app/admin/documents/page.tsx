import { DocumentsPageContent } from "@/features/documents/components/documents-page-content";

export default function DocumentsPage() {
  return <DocumentsPageContent />;
}
