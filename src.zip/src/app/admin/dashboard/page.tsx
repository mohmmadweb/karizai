import { DashboardPageContent } from "@/features/admin-dashboard/components/dashboard-page-content";

export default function DashboardPage() {
  return <DashboardPageContent />;
}
