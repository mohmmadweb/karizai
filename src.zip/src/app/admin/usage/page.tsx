import { UsageReportContent } from "@/features/usage-report/components/usage-report-content";

export default function UsagePage() {
  return <UsageReportContent />;
}
