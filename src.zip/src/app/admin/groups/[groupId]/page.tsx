import { GroupDetail } from "@/features/user-management/components/groups/group-detail";

export default async function GroupPage({
  params,
}: {
  params: Promise<{ groupId: string }>;
}) {
  const { groupId } = await params;
  return <GroupDetail groupId={groupId} />;
}
