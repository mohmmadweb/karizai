import { GroupsPageContent } from "@/features/user-management/components/groups/groups-page-content";

export default function GroupsPage() {
  return <GroupsPageContent />;
}
