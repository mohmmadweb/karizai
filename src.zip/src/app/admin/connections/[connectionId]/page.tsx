import { Suspense } from "react";
import { ListSkeleton } from "@/components/shared/list-skeleton";
import { ConnectionDetail } from "@/features/connections/components/connection-detail";

async function ConnectionContent({ params }: { params: Promise<{ connectionId: string }> }) {
  const { connectionId } = await params;
  return <ConnectionDetail connectionId={connectionId} />;
}

export default function ConnectionPage({ params }: { params: Promise<{ connectionId: string }> }) {
  return (
    <Suspense fallback={<ListSkeleton title="اتصال" />}>
      <ConnectionContent params={params} />
    </Suspense>
  );
}
