import { ApiKeysPageContent } from "@/features/api-keys/components/api-keys-page-content";

export default function ApiKeysPage() {
  return <ApiKeysPageContent />;
}
