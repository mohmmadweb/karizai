import { Suspense } from "react";
import { ListSkeleton } from "@/components/shared/list-skeleton";
import { ModelDetail } from "@/features/models/components/model-detail/model-detail";

async function ModelContent({ params }: { params: Promise<{ modelId: string }> }) {
  const { modelId } = await params;
  return <ModelDetail modelId={modelId} />;
}

export default function ModelPage({
  params,
}: {
  params: Promise<{ modelId: string }>;
}) {
  return (
    <Suspense fallback={<ListSkeleton title="مدل" />}>
      <ModelContent params={params} />
    </Suspense>
  );
}
