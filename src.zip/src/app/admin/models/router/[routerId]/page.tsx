import { Suspense } from "react";
import { ListSkeleton } from "@/components/shared/list-skeleton";
import { RouterDetail } from "@/features/smart-router/components/router-detail";

async function RouterContent({ params }: { params: Promise<{ routerId: string }> }) {
  const { routerId } = await params;
  return <RouterDetail routerId={routerId} />;
}

export default function RouterPage({ params }: { params: Promise<{ routerId: string }> }) {
  return (
    <Suspense fallback={<ListSkeleton title="مسیریاب هوشمند" />}>
      <RouterContent params={params} />
    </Suspense>
  );
}
