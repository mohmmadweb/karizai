import { Suspense } from "react";
import { ListSkeleton } from "@/components/shared/list-skeleton";
import { ProviderModelsPage } from "@/features/models/components/provider-models/provider-models-page";

async function ProviderContent({ params }: { params: Promise<{ providerId: string }> }) {
  const { providerId } = await params;
  return <ProviderModelsPage providerId={providerId} />;
}

export default function ProviderPage({ params }: { params: Promise<{ providerId: string }> }) {
  return (
    <Suspense fallback={<ListSkeleton title="مدل‌های ارائه‌دهنده" />}>
      <ProviderContent params={params} />
    </Suspense>
  );
}
