import { UsersPageContent } from "@/features/user-management/components/users/users-page-content";

export default function UsersPage() {
  return <UsersPageContent />;
}
