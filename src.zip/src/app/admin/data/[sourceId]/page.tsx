import { Suspense } from "react";
import { ListSkeleton } from "@/components/shared/list-skeleton";
import { SourceDetail } from "@/features/data-sources/components/detail/source-detail";

async function SourceContent({ params }: { params: Promise<{ sourceId: string }> }) {
  const { sourceId } = await params;
  return <SourceDetail sourceId={sourceId} />;
}

export default function SourcePage({ params }: { params: Promise<{ sourceId: string }> }) {
  return (
    <Suspense fallback={<ListSkeleton title="داده" />}>
      <SourceContent params={params} />
    </Suspense>
  );
}
