import { DataPageContent } from "@/features/data-sources/components/data-page-content";

export default function DataPage() {
  return <DataPageContent />;
}
