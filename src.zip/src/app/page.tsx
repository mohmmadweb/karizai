export default function Home() {
  return (
    <main className="flex flex-1 items-center justify-center p-6">
      <p>ساختار پروژه آماده است.</p>
    </main>
  );
}
