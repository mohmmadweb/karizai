import type { ReactNode } from "react";
import { AccessProvider } from "@/features/access-control/components/access-provider";
import { getAccessGrants } from "@/features/access-control/data/access-grants";
import { AdminShell } from "@/features/admin-shell/components/admin-shell";
import { DataSourcesProvider } from "@/features/data-sources/components/data-sources-provider";
import { getSchemaDescriptions } from "@/features/data-sources/data/descriptions";
import { getDataSources } from "@/features/data-sources/data/data-sources";
import { getDataSchemas } from "@/features/data-sources/data/schemas";
import { DocumentsProvider } from "@/features/documents/components/documents-provider";
import { getDocuments } from "@/features/documents/data/documents";
import { getFileSources } from "@/features/documents/data/file-sources";
import { ConnectionsProvider } from "@/features/connections/components/connections-provider";
import { RoutersProvider } from "@/features/smart-router/components/routers-provider";
import { PoliciesProvider } from "@/features/policies/components/policies-provider";
import { ModelsProvider } from "@/features/models/components/models-provider";
import { DirectoryProvider } from "@/features/user-management/components/directory-provider";
import { getGroups } from "@/features/user-management/data/groups";
import { getMemberships } from "@/features/user-management/data/memberships";
import { getUsers } from "@/features/user-management/data/users";

export default function AdminLayout({ children }: { children: ReactNode }) {
  return (
    <DirectoryProvider
      initialUsers={getUsers()}
      initialGroups={getGroups()}
      initialMemberships={getMemberships()}
    >
      <AccessProvider initialGrants={getAccessGrants()}>
        <ModelsProvider initialProviders={[]} initialModels={[]}>
          <DataSourcesProvider
            initialSources={getDataSources()}
            initialDescriptions={getSchemaDescriptions()}
            initialDataSchemas={getDataSchemas()}
          >
            <RoutersProvider>
              <ConnectionsProvider>
                <PoliciesProvider>
                  <DocumentsProvider initialDocuments={getDocuments()} initialSources={getFileSources()}>
                    <AdminShell>{children}</AdminShell>
                  </DocumentsProvider>
                </PoliciesProvider>
              </ConnectionsProvider>
            </RoutersProvider>
          </DataSourcesProvider>
        </ModelsProvider>
      </AccessProvider>
    </DirectoryProvider>
  );
}
