import { PoliciesPageContent } from "@/features/policies/components/policies-page-content";

export default function PoliciesPage() {
  return <PoliciesPageContent />;
}
