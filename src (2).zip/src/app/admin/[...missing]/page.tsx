import { notFound } from "next/navigation";

export const instant = false;

/** Unknown addresses inside the admin panel show the not-found page in the admin frame. */
export default function MissingAdminPage() {
  notFound();
}
