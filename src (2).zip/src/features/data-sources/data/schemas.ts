import type { DataSchema } from "../types";

const schemas: DataSchema[] = [
  { id: "schema-001", sourceId: "source-001", name: "فروش", description: "مشتریان و سفارش‌ها.", tableIds: ["tbl-customers", "tbl-orders"] },
  { id: "schema-002", sourceId: "source-001", name: "کاتالوگ", description: "فهرست کالاها و قیمت‌ها.", tableIds: ["tbl-products"] },
];

export function getDataSchemas(): DataSchema[] {
  return schemas;
}
