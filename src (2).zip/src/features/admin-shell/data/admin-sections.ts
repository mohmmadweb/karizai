import {
  BotIcon,
  DatabaseIcon,
  FileTextIcon,
  LayoutDashboardIcon,
  PlugIcon,
  ShieldCheckIcon,
  UsersIcon,
  UsersRoundIcon,
} from "lucide-react";
import type { AdminSection, AdminSectionGroup } from "../types";

const sections: AdminSection[] = [
  {
    id: "section-dashboard",
    slug: "dashboard",
    title: "داشبورد",
    description: "مصرف گروه‌ها، سقف‌ها و وضعیت سامانه.",
    icon: LayoutDashboardIcon,
  },
  {
    id: "section-documents",
    slug: "documents",
    title: "اسناد",
    description: "مدیریت اسناد سازمان.",
    icon: FileTextIcon,
  },
  {
    id: "section-data",
    slug: "data",
    title: "داده",
    description: "اتصال و فعال‌سازی داده‌های سازمان.",
    icon: DatabaseIcon,
  },
  {
    id: "section-users",
    slug: "users",
    title: "کاربران",
    description: "افزودن و مدیریت کاربران سازمان.",
    icon: UsersIcon,
  },
  {
    id: "section-groups",
    slug: "groups",
    title: "گروه‌ها",
    description: "سازمان‌دهی کاربران در گروه‌ها.",
    icon: UsersRoundIcon,
  },
  {
    id: "section-policies",
    slug: "policies",
    title: "سیاست‌ها",
    description: "محرمانگی، بودجه‌ی گروه‌ها، پنهان‌سازی و دسترسی خواندن و نوشتن.",
    icon: ShieldCheckIcon,
  },
  {
    id: "section-models",
    slug: "models",
    title: "مدل‌ها",
    description: "تنظیم مدل‌های هوش مصنوعی در دسترس.",
    icon: BotIcon,
  },
  {
    id: "section-connections",
    slug: "connections",
    title: "اتصال‌ها",
    description: "اتصال به سیستم‌های سازمان و ابزارهایشان.",
    icon: PlugIcon,
  },
];

const byId = (ids: string[]) =>
  ids.map((id) => sections.find((section) => section.id === id)!);

const groups: AdminSectionGroup[] = [
  { id: "monitoring", title: "پایش", sections: byId(["section-dashboard"]) },
  { id: "access", title: "دسترسی", sections: byId(["section-users", "section-groups", "section-policies"]) },
  { id: "intelligence", title: "هوش و دانش", sections: byId(["section-models", "section-documents", "section-data", "section-connections"]) },
];

export function getAdminSectionGroups(): AdminSectionGroup[] {
  return groups;
}

export function getAdminSections(): AdminSection[] {
  return sections;
}

export function getAdminSection(slug: string): AdminSection | undefined {
  return sections.find((section) => section.slug === slug);
}

/** True on the section page and on any page nested inside it. */
export function isSectionPath(pathname: string, section: AdminSection): boolean {
  const base = `/admin/${section.slug}`;
  return pathname === base || pathname.startsWith(`${base}/`);
}
