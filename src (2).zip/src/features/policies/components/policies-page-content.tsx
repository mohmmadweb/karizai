"use client";

import { CircleAlertIcon } from "lucide-react";
import { PageHeader } from "@/components/shared/page-header";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { BudgetTab } from "./budget-tab";
import { ConfidentialityTab } from "./confidentiality-tab";
import { MaskingTab } from "./masking-tab";
import { usePolicies } from "./policies-provider";
import { ToolAccessTab } from "./tool-access-tab";

export function PoliciesPageContent() {
  const { loading, loadError, reload } = usePolicies();
  return (
    <div className="flex flex-col gap-8">
      <PageHeader title="سیاست‌ها" description="محرمانگی اسناد، بودجه‌ی هر گروه، پنهان‌سازی فیلدهای حساس و دسترسی خواندن و نوشتن را در یک جا تعیین کنید." />
      {loading ? (
        <div className="flex flex-col gap-3" aria-busy="true" aria-label="در حال بارگذاری سیاست‌ها">
          <Skeleton className="h-10 w-full max-w-md" />
          <Skeleton className="h-40 w-full" />
        </div>
      ) : loadError ? (
        <Alert variant="destructive">
          <CircleAlertIcon aria-hidden />
          <AlertTitle>{loadError}</AlertTitle>
          <AlertDescription>اتصال به سرور برقرار نشد.</AlertDescription>
          <Button variant="outline" className="mt-2 w-fit" onClick={reload}>تلاش دوباره</Button>
        </Alert>
      ) : (
        <Tabs defaultValue="confidentiality">
          <TabsList className="h-auto max-w-full flex-wrap justify-start">
            <TabsTrigger value="confidentiality">محرمانگی</TabsTrigger>
            <TabsTrigger value="budget">بودجه‌ی گروه‌ها</TabsTrigger>
            <TabsTrigger value="masking">پنهان‌سازی</TabsTrigger>
            <TabsTrigger value="access">خواندن و نوشتن</TabsTrigger>
          </TabsList>
          <TabsContent value="confidentiality" className="pt-4"><ConfidentialityTab /></TabsContent>
          <TabsContent value="budget" className="pt-4"><BudgetTab /></TabsContent>
          <TabsContent value="masking" className="pt-4"><MaskingTab /></TabsContent>
          <TabsContent value="access" className="pt-4"><ToolAccessTab /></TabsContent>
        </Tabs>
      )}
    </div>
  );
}
