"use client";

import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import { defaultPolicies, type Policies } from "@/lib/policies";

type PoliciesContextValue = {
  policies: Policies;
  /** True until the first read finishes. */
  loading: boolean;
  /** Message of the last failed read, or null. */
  loadError: string | null;
  saving: boolean;
  reload: () => void;
  /** Saves the whole policies object; false when the save failed. */
  savePolicies: (next: Policies) => Promise<boolean>;
  /** Changes the confidential flag of one document and saves. */
  setConfidential: (documentId: string, flag: boolean, currentIds: string[]) => Promise<boolean>;
};

const PoliciesContext = createContext<PoliciesContextValue | null>(null);

/**
 * Policies saved on the server (`/api/policies`, shared with the user panel).
 * Reading and saving go through the app's own route; nothing is kept in the browser.
 */
export function PoliciesProvider({ children }: { children: ReactNode }) {
  const [policies, setPolicies] = useState<Policies>(defaultPolicies);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [round, setRound] = useState(0);

  useEffect(() => {
    let alive = true;
    fetch("/api/policies")
      .then((res) => (res.ok ? res.json() : Promise.reject(new Error("read"))))
      .then((body: { policies: Policies }) => {
        if (!alive) return;
        setPolicies(body.policies);
        setLoadError(null);
      })
      .catch(() => alive && setLoadError("خواندن سیاست‌ها شکست خورد."))
      .finally(() => alive && setLoading(false));
    return () => {
      alive = false;
    };
  }, [round]);

  const reload = useCallback(() => {
    setLoading(true);
    setRound((r) => r + 1);
  }, []);

  const savePolicies = useCallback(async (next: Policies) => {
    setSaving(true);
    try {
      const res = await fetch("/api/policies", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ policies: next }),
      });
      if (!res.ok) return false;
      setPolicies(next);
      return true;
    } catch {
      return false;
    } finally {
      setSaving(false);
    }
  }, []);

  const value = useMemo<PoliciesContextValue>(
    () => ({
      policies,
      loading,
      loadError,
      saving,
      reload,
      savePolicies,
      setConfidential: (documentId, flag, currentIds) => {
        const rest = currentIds.filter((id) => id !== documentId);
        return savePolicies({ ...policies, confidentialDocumentIds: flag ? [...rest, documentId] : rest });
      },
    }),
    [policies, loading, loadError, saving, reload, savePolicies],
  );

  return <PoliciesContext.Provider value={value}>{children}</PoliciesContext.Provider>;
}

export function usePolicies(): PoliciesContextValue {
  const value = useContext(PoliciesContext);
  if (!value) throw new Error("usePolicies must be used inside PoliciesProvider.");
  return value;
}
